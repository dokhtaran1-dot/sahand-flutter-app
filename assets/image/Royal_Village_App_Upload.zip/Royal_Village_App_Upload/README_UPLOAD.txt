ROYAL VILLAGE APP UPLOAD PACK
Optimized WebP images for app/CDN upload.
01_Cakes
02_Fruit
03_Drinks
04_Desserts
05_Food
06_Hookah_VIP
07_Menu_Posters
